/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize The Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map inputs to outputs -> The Process 
    
    //Display Results
    cout<<"Hello World"<<endl;
    //Another way to do the same thing!
    cout<<"Hello "<<"World"<<endl;
    //Another way to do the same thing!
    cout
            <<"Hello "
            <<"World"
            <<endl;
    //Another way to do the same thing
     cout<<"Hello ";
     cout<<"World";
     cout<<endl;
    
    //Exit stage right
    return 0;
}

