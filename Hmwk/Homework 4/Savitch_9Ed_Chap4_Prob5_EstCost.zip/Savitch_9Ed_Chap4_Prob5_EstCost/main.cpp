/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    float current_price,year_ago,one_year,two_year,inflation;
    char response;
    do
    {
        cout<<"Enter current price:"<<endl;
        cin>>current_price;
        cout<<"Enter year-ago price:"<<endl;
        cin>>year_ago;
        inflation=(current_price-year_ago)/year_ago*100.00;
        cout<<"Inflation rate: "<<setprecision(4)<<inflation<<"%"<<endl;
        one_year=current_price*(1+inflation/100.00);
        two_year=one_year*(1+inflation/100.00);
        cout<<"\nPrice in one year: $"<<one_year;
        cout<<"\nPrice in two year: $"<<two_year<<endl;
        cout<<"\nAgain:"<<endl<<endl;
        cin>>response;
    }while(response!='n');
    return 0;
}
