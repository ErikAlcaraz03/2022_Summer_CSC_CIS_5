/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <iostream>
using namespace std;
const float GALLONS_PER_LITER = 0.264179;
float MilesPerGallon(float miles, float gallons);

int main() {


	int liters;
	float miles;
	float MPG;
	char repeat;
	do
	{
		cout << "Enter number of liters of gasoline:"<<endl<<endl;
		cin >> liters;

		cout << "Enter number of miles traveled:"<<endl<<endl;
		cin >> miles;
		MPG = miles / (liters * GALLONS_PER_LITER);
		//display results
		cout.setf(ios::fixed);
		cout.setf(ios::showpoint);
		cout.precision(2);


		cout << "miles per gallon:"<<endl<< MPG<<endl;

		cout << "Again:\n"<<endl;
	
		cin >> repeat;
	} while (repeat == 'Y' || repeat == 'y');
	
		cin >> repeat;
	return 0;
}
float MilesPerGallon(float miles, float gallons) {
	return (miles / gallons);
}

