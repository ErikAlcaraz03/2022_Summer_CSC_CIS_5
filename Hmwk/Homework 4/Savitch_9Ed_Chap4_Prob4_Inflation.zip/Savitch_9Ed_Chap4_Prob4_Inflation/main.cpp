/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include<iostream>
#include<cmath>
#include <iostream>
#include <iomanip>
using namespace std;
// function to compute the rate of inflation.
float inflationMethod(float year_ago_price,float current_price)
{  
    // It estimates the inflation rate as a difference in price divided by the year ago price.
    return ((current_price-year_ago_price)/year_ago_price);
}
int main()
{
   float year_ago_price,current_price,rate;
   char option;
   do {
    //   The program asked for the price of an item such as a hotdog or a one karat diamond both one year ago and today.
       cout<<"Enter.current.price:"<<endl;
       cin>>current_price;
       cout<<"Enter.year-ago.price:"<<endl;
       cin>>year_ago_price;
       rate = inflationMethod(year_ago_price,current_price);
       cout<<"Inflation.rate: ";
    //   to gauge the rate of flation for the past year.
       cout << std::fixed << std::setprecision(2) << rate*100<<"%"<<endl;
      cout<<endl;
    //   program should allowed to use it to repeat this calculation as often as a user wishes.
       cout<<"Again:"<<endl;
       cin>>option;
       cout<<endl;
   } while (option=='y');
}

