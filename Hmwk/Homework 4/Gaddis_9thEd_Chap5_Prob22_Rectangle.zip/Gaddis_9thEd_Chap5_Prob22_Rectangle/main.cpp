/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include<iostream>
#include<string>

using namespace std;

int main()
{
int isize=1;
cin>>isize;
string myY(isize,88);
for(int i=1;i<isize;i++)
cout<<myY<<endl;
cout<<myY;
}

