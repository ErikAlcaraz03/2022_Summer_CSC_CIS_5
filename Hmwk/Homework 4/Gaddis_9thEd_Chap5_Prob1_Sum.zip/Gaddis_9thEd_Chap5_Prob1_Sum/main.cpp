/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include<iostream>
using namespace std;
int main()
{
long sum=0;
int num;
cin>>num;
for(int v=1;v<=num;v++)
sum=sum+v;
cout<<"Sum = "<<sum;
return 0;
}

