/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <stdio.h>
#include<math.h>
float twoparameter(float a,float b)
{
if(a>b)
return floor(a*10)/10;
else
return floor(b*10)/10;
}
float threeparameter(float a,float b,float c)
{
if(a>b && a>c)
return floor(a*10)/10;
else if(b>a && b>c)
return floor(b*10)/10;
else
return floor(c*10)/10;
}
int main()
{
float a,b,c;
printf("Enter first number:\n");
scanf("%f",&a);
printf("Enter Second number:\n");
scanf("%f",&b);
printf("Enter third number:\n");
scanf("%f",&c);
printf("Largest number from two parameter function:\n%.1f",twoparameter(a,b));
printf("\n\nLargest number from three parameter function:\n%.1f",threeparameter(a,b,c));
return 0;
}

