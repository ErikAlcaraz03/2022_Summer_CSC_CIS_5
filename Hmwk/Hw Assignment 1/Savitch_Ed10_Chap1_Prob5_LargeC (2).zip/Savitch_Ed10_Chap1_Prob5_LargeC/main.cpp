/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <iostream>
using namespace std;

int main(){
cout << "\n";
  cout << "\n";
  cout << "            X X X           \n";
  cout << "           X    X          \n";
  cout << "          X                  \n";
  cout << "         X                   \n";
  cout << "         X                   \n";
  cout << "         X                   \n";
  cout << "          X                  \n";
  cout << "           X    X          \n";       
  cout << "            X X X           \n";               
  cout << "\n";
 
	
	
	return 0;
 }