/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: Diamond Pattern
 */

//System Libraries
#include <iostream>  //Input-Output Library
using namespace std;

//User Defined Libraries

//Global Constants,not Global Variables
//These are recognized constants from the sciences 
//Physics/Chemistry/Engineering and Conversions between
//systems of units!

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Initialize Random Seed once here!
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map the inputs/known to the outputs 
    
    //Display the outputs
    cout<<"   *"<<endl;
    cout<<"  ***"<<endl;
    cout<<" *****"<<endl;
    cout<<"*******"<<endl;
    cout<<" *****"<<endl;
    cout<<"  ***"<<endl;
    cout<<"   *"<<endl;
    
    //Exit stage right
    return 0;
}

