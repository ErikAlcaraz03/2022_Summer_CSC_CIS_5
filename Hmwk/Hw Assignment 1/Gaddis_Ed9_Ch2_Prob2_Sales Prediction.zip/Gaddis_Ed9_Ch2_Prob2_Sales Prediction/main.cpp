/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <iostream>
using namespace std;
int main()
{
    //total sale of the company
    float total_sale=8.6;
    
    // variable to store division generated
    float east_total;
    
    //computing east_total
    east_total=(58)*(total_sale)/100;
    
    //printing result on screen 
    cout<<"\n The East Coast division will generate "<<east_total<<"million dollars";

    return 0;
}

