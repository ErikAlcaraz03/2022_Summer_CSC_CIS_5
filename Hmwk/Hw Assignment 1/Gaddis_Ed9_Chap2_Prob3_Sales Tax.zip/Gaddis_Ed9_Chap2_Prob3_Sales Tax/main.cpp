/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <iostream>
using namespace std;

int main()

{

   float purchasePrice = 95;

   float stateSalesTaxRate = 0.06;

   float countySalesTaxRate = 0.02;

   float totalSalesTax;

   

   totalSalesTax = (purchasePrice * stateSalesTaxRate)  + (purchasePrice * countySalesTaxRate);

   

   cout << totalSalesTax << endl;

   return 0;

}

