/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <iostream>
using namespace std;
 // header file
int main() // main function

{

int a=50,b=100,total; // variable declaration

total=a+b; // sum of the two variable a and b

cout<<"The total is:"<<total; // display total

return 0;

}

