/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <iostream>
using namespace std;
//Header file

//main function
int main( ) 
{
	//Variable declaration
	int first_num,second_num,sum,product;
	//Prompt the user to enter input
	cout << "Enter an integer followed by the Enter Key: ";
	cin >> first_num;
	cout << "Enter second Integer followed by the Enter Key: ";
	cin >> second_num;

	//Sum calculation
	sum=first_num+second_num;

	cout << "Sum of two numbers:"<<sum<<endl;
	//Product calculation
	product=first_num*second_num;

	cout << "Product of two numbers:"<<product<<endl;
	return 0;
 }



