/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <iostream>
using namespace std;
#include <iostream>

using namespace std;

int main()

{

//declare all the required fields in double format

   float mealCost =88.67;

   float taxPercenatage=6.75;

   float tipPercentage=20;

// displaying the original Meal Cost

   cout<< "Meal Cost: "<<mealCost<<endl;

// get the total tax percentage from meal cost

   float totalTax= taxPercenatage /100 * mealCost;

// display the tax amount

   cout<< "Tax Amount: "<<totalTax<<endl;

// getting tip amount from meal cost and tax amount.

  float totalTip = tipPercentage/100 * (mealCost+totalTax);

//displaying tip amount

   cout<< "Tip Amount: "<<totalTip<<endl;

// now adding all three values and get total amount that customer

// has to pay

   float totalAmount = mealCost+totalTax+totalTip;

//Displaying total amount

   cout<< "Total Bill: "<<totalAmount<<endl;


    return 0;
}

