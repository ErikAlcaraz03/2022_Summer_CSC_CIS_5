/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

int main()
{
cout << "Insurance Calculator" <<endl;
cout << "How much is your house worth? " <<endl;
double value;
cin >> value;
cout << "You need $" << 0.8 * value << " of insurance."<<endl;

return 0;
}

