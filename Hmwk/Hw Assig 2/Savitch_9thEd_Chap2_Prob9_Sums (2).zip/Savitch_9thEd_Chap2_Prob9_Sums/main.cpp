/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <iostream>
using namespace std;
int main ()
{
int number, neg_sum=0, pos_sum=0, sum=0;
cout <<"Input 10 numbers, any order, positive or negative"<<endl;
for(int i=0;i<10;i++)
{
cin >> number;
if (number <= 0 )
{
neg_sum += number;
}
else
{
pos_sum += number ;
}
}
sum = neg_sum + pos_sum;
cout << "Negative sum = " << neg_sum << endl;
cout << "Positive sum =  " << pos_sum << endl;
cout << "Total sum    =   " << sum;
return 0;
}

