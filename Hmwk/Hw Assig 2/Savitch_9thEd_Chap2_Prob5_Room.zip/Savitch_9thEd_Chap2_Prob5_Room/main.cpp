/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <iostream>

using namespace std;

int main()
{
int maxnumber;
int number;
int diff;

cout << "Input the maximum room capacity";
cin >> maxnumber;
cout << " and the number of people"<<endl;
cin >> number;
if(number>maxnumber){
diff=number-maxnumber;
cout << "Meeting cannot be held."<<endl;
cout<< "Reduce number of people by 100 to avoid fire violation.";
}
else if(number<=maxnumber){
diff=maxnumber-number;
cout << "Meeting can be held."<<endl; 
cout<< "Increase number of people by 100 will be allowed without violation.";
}
return 0;
}

