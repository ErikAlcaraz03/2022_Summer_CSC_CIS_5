/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include<iostream>
using namespace std;
int main(){
    char repeat='n';
    const float sweetner_isto_mass = 1/7;  //ratio 5gm sweetner for 35gm weight
    float weight = 45400; // weight of person in grams
    const float sweetner_in_soda = 0.001;   // 0.001 part of 1gm soda is sweetner
    float stopWeight;
    do{
        cout<<"\nEnter weight at which to stop diet(in pounds):";
        cin>>stopWeight;
        stopWeight *= 454;    //conversion to grams
        float soda = (stopWeight/7);
        cout<<"\nYou can consume "<<soda<<" kgs of soda before you die.\n";
        cout<<"Do you want to check again(y/n)?";
        cin>>repeat;
        
    }while(repeat=='y');
    return 0;
}

