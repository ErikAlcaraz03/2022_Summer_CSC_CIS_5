/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <iostream>

using namespace std;

int main(){

float salary=0;

char cont = 'n';

const float rate= .076;

int months;

{

cout << "Input previous annual salary. "<< endl;

cin >> salary;

cout << "Retroactive pay    = " <<  ((.076*salary) + (salary)) /

months << endl;

cout << "New annual salary  = " << (.076*salary) +

(salary) << endl;

cout << "New monthly salary = $ " << (.076*salary) +

(salary) / (12) << endl;

cout << endl;

}while( cont == 'y' || cont == 'Y');

return 0;

}

