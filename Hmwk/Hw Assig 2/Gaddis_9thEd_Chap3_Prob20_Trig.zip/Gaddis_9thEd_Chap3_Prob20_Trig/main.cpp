/* 
 * File:   CPPTemplate
 * Author: Erik Alcaraz
 * Created on June 22, 2022, 2:32 PM
 * Purpose: C++ Template - To be used in all future Assignments
 */

//System Libraries
#include <iostream>
#include <math.h>
using namespace std;

// Function for conversion
double Convert(double degree)
{
double pi = 3.14;
return (degree * (pi / 180));
}
int main()
{
double deg ;
cout<<"enter the degree of an angle"<<endl;
cin>>deg;
double rad = Convert(deg);
cout <<"degree="<<deg<<"\nradian="<< rad<<endl;
cout << "Sine value="<< sin(rad) << endl;
cout << "Cosine value="<< cos(rad) << endl;
cout << "Tangent value="<< tan(rad) << endl;
return 0;
}


