/* 
 * File:   Gas Cost
 * Author: Erik Alcaraz
 * Created on June 24, 2022, 8:51 PM
 * Purpose: To find which option is cheaper
 */

//System Libraries
#include <iostream>
using namespace std;
int main()
{
    float ggauge,tankSize,mpg,greq,fill;
    cout<<"Enter gas gauge in % then press enter:"<<endl;
    cin>>ggauge;
    cout<<"Enter tank size in gallon then press enter:"<<endl;
    cin>>tankSize;
    cout<<"Enter gas milage(mpg) then press enter:"<<endl;
    cin>>mpg;
    fill=((100-ggauge)*tankSize/100);
    cout<<"Gallons required to fill up then press enter:"<<fill<<endl;
    // gas price for 1st station
    float gp1,ms1,gp2,ms2,c1,c2;
    cout<<"Regular gas per gallon $ then press enter"<<endl;
    cin>>gp1;
    cout<<"Miles to gas station then press enter:"<<endl;
    cin>>ms1;
    cout<<"Cost to fill up $"<<(fill*gp1)<<endl;
    cout<<"Total distance driven in miles back and forth gas station:"<<2*ms1<<endl;
    c1=(2*ms1/mpg)*gp1;
    cout<<"Cost to drive to and from gas station $"<<c1<<endl;
    cout<<"Total cost with milage to gas station $"<<c1+(fill*gp1)<<endl;
    cout<<"Price per gallon when added to milage $"<<(c1+(fill*gp1))/fill<<endl;

    // gas price for 2nd station
    cout<<"Regular gas per gallon $"<<endl;
    cin>>gp2;
    cout<<"Miles to gas station:"<<endl;
    cin>>ms2;
    cout<<"Cost to fill up $"<<(fill*gp2)<<endl;
    cout<<"Total distance driven in miles back and forth gas station:"<<2*ms2<<endl;
    c2=(2*ms2/mpg)*gp2;
    cout<<"Cost to drive to and from gas station $"<<c2<<endl;
    cout<<"Total cost with milage to gas station $"<<c2+(fill*gp2)<<endl;
    cout<<"Price per gallon when added to milage $"<<(c2+(fill*gp2))/fill<<endl;
 
    return 0;
} 


